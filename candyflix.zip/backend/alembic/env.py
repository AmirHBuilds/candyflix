"""
Alembic migration environment.

Uses the same DATABASE_URL as the application (via app.core.config),
converted to a sync driver for migrations, and app.core.db.Base's
metadata as the autogenerate target.
"""
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

from app.core.config import get_settings
from app.core.db import Base

# Import models here so Alembic's autogenerate can see them.
from app.models import user  # noqa
from app.models import watch_progress  # noqa
from app.models import watchlist_item  # noqa
from app.models import user_settings  # noqa
from app.models import video_settings  # noqa
from app.models import site_setting  # noqa

config = context.config

if config.config_file_name is not None:
    # disable_existing_loggers=False: this also runs inside the live app
    # (app/core/migrate.py), and the default would silence its loggers.
    fileConfig(config.config_file_name, disable_existing_loggers=False)

target_metadata = Base.metadata

settings = get_settings()
sync_url = settings.database_url.replace("postgresql+asyncpg", "postgresql+psycopg2")
config.set_main_option("sqlalchemy.url", sync_url)


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()

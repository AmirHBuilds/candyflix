"""
Playback source & watch-progress routes.

All routes here are auth-protected — playback progress is inherently
per-user (Candy, Mom, and Sister never see each other's positions).
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.db import get_db
from app.models.user import User
from app.providers import mock_provider
from app.providers.mock_provider import MockVideoNotConfigured
from app.schemas.playback import EpisodeVisitIn, MovieVisitIn, PlaybackSource, WatchProgressIn, WatchProgressOut
from app.schemas.video_settings import ClearedResult
from app.services import content_rating_service, resolver_service, subtitle_service, subtitle_sync_service, video_settings_service, watch_progress_service

router = APIRouter(tags=["playback"])


def _subtitle_tracks(default_track, media_type, tmdb_id, season_number, episode_number):
    """The default track, plus any synced subtitles kept for this video. A synced
    track replaces the unsynced one of the same language."""
    synced = subtitle_sync_service.synced_tracks_for_video(
        subtitle_sync_service.video_key(media_type, tmdb_id, season_number, episode_number)
    )
    tracks = [default_track] if default_track else []
    synced_languages = {t.language for t in synced}
    return [t for t in tracks if t.language not in synced_languages] + synced


@router.get("/playback/movie/{tmdb_id}", response_model=PlaybackSource)
async def playback_movie(
    tmdb_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await content_rating_service.ensure(current_user, "movie", tmdb_id)
    # Real video (Candy Resolver): there is no file yet, the player asks /api/resolve for one.
    live = resolver_service.enabled()
    try:
        url = "" if live else mock_provider.get_mock_video_url()
    except MockVideoNotConfigured as e:
        raise HTTPException(status_code=404, detail=str(e))

    default_track = await subtitle_service.get_default_english_track("movie", tmdb_id, None, None)

    progress = await watch_progress_service.get_progress(
        db, current_user.id, tmdb_id, "movie", None, None
    )
    return PlaybackSource(
        source_type="resolver" if live else "mock",
        url=url,
        subtitles=_subtitle_tracks(default_track, "movie", tmdb_id, None, None),
        resume_position_seconds=progress.position_seconds if progress else None,
        video_settings=await video_settings_service.get(db, current_user.id, tmdb_id, "movie", None, None),
    )


@router.get("/playback/tv/{tmdb_id}/{season_number}/{episode_number}", response_model=PlaybackSource)
async def playback_episode(
    tmdb_id: int,
    season_number: int,
    episode_number: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await content_rating_service.ensure(current_user, "tv", tmdb_id)
    live = resolver_service.enabled()
    try:
        url = "" if live else mock_provider.get_mock_video_url()
    except MockVideoNotConfigured as e:
        raise HTTPException(status_code=404, detail=str(e))

    default_track = await subtitle_service.get_default_english_track(
        "tv", tmdb_id, season_number, episode_number
    )

    progress = await watch_progress_service.get_progress(
        db, current_user.id, tmdb_id, "tv", season_number, episode_number
    )
    return PlaybackSource(
        source_type="resolver" if live else "mock",
        url=url,
        subtitles=_subtitle_tracks(default_track, "tv", tmdb_id, season_number, episode_number),
        resume_position_seconds=progress.position_seconds if progress else None,
        video_settings=await video_settings_service.get(
            db, current_user.id, tmdb_id, "tv", season_number, episode_number
        ),
    )


@router.post("/watch-progress", response_model=WatchProgressOut)
async def save_watch_progress(
    payload: WatchProgressIn,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await content_rating_service.ensure(current_user, payload.media_type, payload.tmdb_id)
    row = await watch_progress_service.save_progress(
        db,
        current_user.id,
        payload.tmdb_id,
        payload.media_type,
        payload.season_number,
        payload.episode_number,
        payload.position_seconds,
        payload.duration_seconds,
    )
    return watch_progress_service.to_watch_progress_out(row)


@router.post("/watch-progress/tv/visit", status_code=204)
async def record_episode_visit(
    payload: EpisodeVisitIn,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Called by the watch page the moment it renders, before the video
    element (or the player's own save logic) has done anything — see
    watch_progress_service.mark_episode_visited for why: without this, a
    click that's closed within a second could leave no real save at all,
    and the NEXT visit would show the previous episode as last watched.
    """
    await content_rating_service.ensure(current_user, "tv", payload.tmdb_id)
    await watch_progress_service.mark_episode_visited(
        db, current_user.id, payload.tmdb_id, payload.season_number, payload.episode_number
    )


@router.post("/watch-progress/movie/visit", status_code=204)
async def record_movie_visit(
    payload: MovieVisitIn,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """The movie twin of /watch-progress/tv/visit — keeps a movie in
    Continue Watching even when position saving is switched off."""
    await content_rating_service.ensure(current_user, "movie", payload.tmdb_id)
    await watch_progress_service.mark_movie_visited(db, current_user.id, payload.tmdb_id)


@router.delete("/watch-progress", response_model=ClearedResult)
async def clear_watch_history(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Settings -> Privacy & data -> Clear watch history: forgets every
    resume position, last-watched episode and Continue Watching entry."""
    return ClearedResult(cleared=await watch_progress_service.clear_all_progress(db, current_user.id))


@router.get("/watch-progress/movie/{tmdb_id}", response_model=WatchProgressOut | None)
async def get_watch_progress_movie(
    tmdb_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    row = await watch_progress_service.get_progress(db, current_user.id, tmdb_id, "movie", None, None)
    return watch_progress_service.to_watch_progress_out(row) if row else None


@router.get(
    "/watch-progress/tv/{tmdb_id}/{season_number}/{episode_number}",
    response_model=WatchProgressOut | None,
)
async def get_watch_progress_episode(
    tmdb_id: int,
    season_number: int,
    episode_number: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    row = await watch_progress_service.get_progress(
        db, current_user.id, tmdb_id, "tv", season_number, episode_number
    )
    return watch_progress_service.to_watch_progress_out(row) if row else None


@router.get("/watch-progress/tv/{tmdb_id}/latest", response_model=WatchProgressOut | None)
async def get_latest_watch_progress_tv(
    tmdb_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Backs the TV detail page's "Watch Now" button — the most recent
    episode this user has any progress on, or null if they've never
    started the show. No collision with the {season_number}/{episode_number}
    route above despite both starting with /watch-progress/tv/{tmdb_id}/:
    that route has two more path segments, this one has one, so they're
    structurally distinct regardless of declaration order."""
    row = await watch_progress_service.get_latest_progress_for_title(
        db, current_user.id, tmdb_id, "tv"
    )
    return watch_progress_service.to_watch_progress_out(row) if row else None


@router.get(
    "/watch-progress/tv/{tmdb_id}/season-progress",
    response_model=list[WatchProgressOut],
)
async def list_watch_progress_for_season(
    tmdb_id: int,
    season_number: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Backs the episode list's "you've seen this one" highlighting —
    every episode of this season with any saved progress.

    season_number is a query param, not a path segment, on purpose:
    /watch-progress/tv/{tmdb_id}/{season_number}/{episode_number} above
    already claims the "two more segments" shape, and FastAPI/Starlette
    matches routes by path structure at the string level (the `int` type
    hints only validate *after* a route structurally matches — they
    aren't compiled into the matching pattern unless you write
    `{name:int}` explicitly). A path route here, e.g. .../season/{n},
    would have the same two-segment shape as the episode route and could
    get matched by it first (then 422 on `int("season")`) depending on
    registration order. A query param sidesteps the ambiguity entirely.
    """
    rows = await watch_progress_service.list_progress_for_season(
        db, current_user.id, tmdb_id, season_number
    )
    return [watch_progress_service.to_watch_progress_out(row) for row in rows]

"""Footer content shown on every page; edited by admins."""
import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

_URL = re.compile(r"^(https?://|mailto:|/)\S+$", re.IGNORECASE)
_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class FooterLink(BaseModel):
    model_config = ConfigDict(extra="forbid")
    label: str = Field(min_length=1, max_length=40)
    url: str = Field(max_length=300)

    @field_validator("label")
    @classmethod
    def _label(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Link label can't be empty")
        return v

    @field_validator("url")
    @classmethod
    def _url(cls, v: str) -> str:
        v = v.strip()
        if not _URL.match(v):
            raise ValueError("Link must start with http://, https://, mailto: or /")
        return v


class Footer(BaseModel):
    model_config = ConfigDict(extra="forbid")
    enabled: bool = True
    tagline: str = Field(default="Your own private movie night.", max_length=160)
    email: str = Field(default="", max_length=120)
    links: list[FooterLink] = Field(default_factory=list, max_length=8)
    copyright: str = Field(default="CandyFlix", max_length=80)

    @field_validator("email")
    @classmethod
    def _email(cls, v: str) -> str:
        v = v.strip()
        if v and not _EMAIL.match(v):
            raise ValueError("That doesn't look like an email address")
        return v

    @field_validator("tagline", "copyright")
    @classmethod
    def _strip(cls, v: str) -> str:
        return v.strip()


class Banner(BaseModel):
    """One of the three feature banners on the home page. The picture is fixed per slot; the words are the admin's."""

    model_config = ConfigDict(extra="forbid")
    enabled: bool = True
    title: str = Field(default="", max_length=60)
    text: str = Field(default="", max_length=220)

    @field_validator("title", "text")
    @classmethod
    def _strip(cls, v: str) -> str:
        return v.strip()


DEFAULT_BANNERS = [
    Banner(
        title="Subtitles that fit",
        text="Pick a subtitle from OpenSubtitles, then tap Sync and CandyFlix lines it up with the video's audio. It remembers the fixed one for next time.",
    ),
    Banner(
        title="Right where you left off",
        text="Resume any movie or episode from the same spot, skip intros with one tap, and keep your own CandyBox of things to watch.",
    ),
    Banner(
        title="Make it yours",
        text="Pick a colour theme, arrange the player's buttons, peek at every rating, and watch a trailer before you commit to movie night.",
    ),
]


class HomeBanners(BaseModel):
    model_config = ConfigDict(extra="forbid")
    banners: list[Banner] = Field(default_factory=lambda: [b.model_copy() for b in DEFAULT_BANNERS], min_length=3, max_length=3)

    @field_validator("banners")
    @classmethod
    def _enabled_ones_need_words(cls, v: list[Banner]) -> list[Banner]:
        for b in v:
            if b.enabled and not (b.title and b.text):
                raise ValueError("A banner that is switched on needs a title and some text")
        return v


class AIConfig(BaseModel):
    """Site-wide Ask AI controls (admin). The daily number is what people without their own number get."""

    enabled: bool = True
    default_daily_limit: int = Field(default=5, ge=0, le=1000)
    # The watch assistant (player side panel) has its own switch and number.
    watch_enabled: bool = True
    watch_daily_limit: int = Field(default=20, ge=0, le=1000)


class SocialConfig(BaseModel):
    """Site-wide switches for opinions and likes (admin)."""

    enabled: bool = True
    allow_anonymous: bool = True
    allow_replies: bool = True
    home_section: bool = True


BadgePosition = Literal["top", "top-left", "top-right"]


class AdminBadge(BaseModel):
    """What admins' profiles wear on the login screen. `image` is a stored file name (None = the built-in crown)."""

    position: BadgePosition = "top-left"
    image: str | None = None


class BadgePublic(BaseModel):
    position: BadgePosition = "top-left"
    image_url: str | None = None  # None = draw the built-in crown


class BadgePositionUpdate(BaseModel):
    position: BadgePosition


class PlaybackConfig(BaseModel):
    """Site-wide playback switches (admin)."""

    # Near the end of an episode (95%), start getting the next episode ready at the video service.
    prefetch_next_episode: bool = True


class SharingConfig(BaseModel):
    """When an account looks shared: signed in from this many different addresses within this many hours (admin)."""

    enabled: bool = True
    max_ips: int = Field(default=4, ge=2, le=50)
    window_hours: int = Field(default=24, ge=1, le=720)


class LoginGuardConfig(BaseModel):
    """Limits on wrong passwords (admin). Too many wrong tries for one name, or from one address, blocks further tries for a while."""

    enabled: bool = True
    name_failures: int = Field(default=5, ge=2, le=50)  # wrong passwords for one name ...
    ip_failures: int = Field(default=20, ge=3, le=500)  # ... or from one address ...
    window_minutes: int = Field(default=15, ge=1, le=1440)  # ... within this long
    lockout_minutes: int = Field(default=15, ge=1, le=1440)  # the first block lasts this long; repeats double it (up to 4x)


class DeviceConfig(BaseModel):
    """Limits on devices (a browser or phone someone signs in from) per account (admin)."""

    enabled: bool = True
    max_devices_per_day: int = Field(default=3, ge=1, le=50)  # different devices that sign in within 24 hours
    max_active: int = Field(default=5, ge=1, le=50)  # devices signed in at the same time
    action: str = Field(default="alert", pattern="^(alert|refuse|oldest)$")  # what happens at the limit (admins are never refused)
    notify_user: bool = True  # tell the person on Telegram when a device they never used before signs in

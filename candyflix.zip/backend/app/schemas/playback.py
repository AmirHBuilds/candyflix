"""
Playback & watch-progress schemas.

PlaybackSource is intentionally provider-agnostic: source_type is
"mock" today, with "embed" and "hls" reserved for future phases (legit
external links, or a self-hosted Candy Server). The player component
should only ever branch on source_type, never assume "mock".
"""
from datetime import datetime
from typing import Literal

from pydantic import BaseModel


class SubtitleTrackOut(BaseModel):
    language: str  # e.g. "en" — drives the menu label and <track> lang attr
    label: str  # human-readable, e.g. "English"
    url: str
    format: Literal["srt", "vtt"]  # frontend converts srt -> vtt before use
    # True for a subtitle the server re-timed against this video's audio
    # (Phase 11). It replaces the unsynced track of the same language.
    synced: bool = False
    # Where the track came from: "source" = delivered with the video by its
    # source (none yet with the mock provider), "opensubtitles" = fetched from
    # OpenSubtitles. The player's subtitle menu sorts tracks into tabs by this.
    origin: Literal["source", "opensubtitles"] = "source"


class PlaybackSource(BaseModel):
    source_type: Literal["mock", "resolver"]
    url: str
    subtitles: list[SubtitleTrackOut]
    resume_position_seconds: float | None = None
    # This person's saved per-video tweaks (volume, subtitle language, ...);
    # {} when none. The player only applies them if "Remember settings per
    # video" is on.
    video_settings: dict = {}


class WatchProgressIn(BaseModel):
    tmdb_id: int
    media_type: Literal["movie", "tv"]
    season_number: int | None = None  # None for movies
    episode_number: int | None = None  # None for movies
    position_seconds: float
    duration_seconds: float


class EpisodeVisitIn(BaseModel):
    tmdb_id: int
    season_number: int
    episode_number: int


class MovieVisitIn(BaseModel):
    tmdb_id: int


class WatchProgressOut(BaseModel):
    tmdb_id: int
    media_type: Literal["movie", "tv"]
    season_number: int | None
    episode_number: int | None
    position_seconds: float
    duration_seconds: float
    # Exposed so a client can rank several episodes of saved progress by
    # recency itself (e.g. the TV detail page picking which non-resume
    # episode is worth flagging as "In progress") without a second,
    # more specific endpoint for every such ranking need.
    updated_at: datetime

    model_config = {"from_attributes": True}

import { getTVGenres, getPopularTVPage, type Genre, type MediaItem } from "@/lib/media";
import { authInit } from "@/lib/media-server";
import MediaBrowser from "@/components/MediaBrowser";
import ErrorState from "@/components/ErrorState";

export default async function SeriesPage() {
  let items: MediaItem[] = [];
  let hasMore = false;
  let genres: Genre[] = [];
  let error: string | null = null;

  try {
    const auth = await authInit();
    const [page, genreList] = await Promise.all([getPopularTVPage(1, auth), getTVGenres(auth)]);
    items = page.items;
    hasMore = page.hasMore;
    genres = genreList;
  } catch {
    error = "Couldn't load series right now. Try refreshing in a moment.";
  }

  return (
    <div className="flex flex-col gap-6">
      <h1 className="font-[family-name:var(--font-display)] text-2xl font-semibold">Series</h1>
      {error ? (
        <ErrorState message={error} />
      ) : (
        <MediaBrowser
          mediaType="tv"
          genres={genres}
          initialItems={items}
          initialHasMore={hasMore}
          emptyLabel="No series match your filters."
          errorLabel="Couldn't load more series right now. Try again in a moment."
        />
      )}
    </div>
  );
}

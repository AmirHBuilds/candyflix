import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import "@testing-library/jest-dom/vitest";
import { act, fireEvent, render, screen, waitFor } from "@testing-library/react";

const hlsInstances: Array<{ on: ReturnType<typeof vi.fn>; loadSource: ReturnType<typeof vi.fn>; attachMedia: ReturnType<typeof vi.fn>; destroy: ReturnType<typeof vi.fn> }> = [];
vi.mock("hls.js", () => {
  class FakeHls {
    static isSupported() {
      return true;
    }
    static Events = { ERROR: "e", FRAG_LOADED: "f" };
    static ErrorTypes = { NETWORK_ERROR: "n", MEDIA_ERROR: "m" };
    loadSource = vi.fn();
    attachMedia = vi.fn();
    destroy = vi.fn();
    on = vi.fn();
    startLoad = vi.fn();
    stopLoad = vi.fn();
    recoverMediaError = vi.fn();
    constructor() {
      hlsInstances.push(this);
    }
  }
  return { default: FakeHls };
});
vi.mock("@/lib/playback", async () => {
  const actual = await vi.importActual<typeof import("@/lib/playback")>("@/lib/playback");
  return {
    ...actual,
    navigateWithResumeHint: vi.fn(),
    patchVideoSettings: vi.fn(),
    searchOnlineSubtitles: vi.fn().mockResolvedValue({ results: [], hasMore: false }),
    saveWatchProgress: vi.fn().mockResolvedValue(undefined),
    saveWatchProgressBeacon: vi.fn(),
    recordEpisodeVisit: vi.fn(),
    recordMovieVisit: vi.fn(),
    getSegments: vi.fn().mockResolvedValue({ intro: null, recap: null, credits: null }),
  };
});
vi.mock("@/lib/settings", async () => {
  const actual = await vi.importActual<typeof import("@/lib/settings")>("@/lib/settings");
  return { ...actual, patchSettings: vi.fn(), resetSettings: vi.fn(), getSettings: vi.fn() };
});
vi.mock("@/lib/resolve", async () => {
  const actual = await vi.importActual<typeof import("@/lib/resolve")>("@/lib/resolve");
  return { ...actual, startResolve: vi.fn(), getResolveState: vi.fn(), requestDownload: vi.fn(), loadMoreSources: vi.fn(), prefetchTitle: vi.fn().mockResolvedValue({ started: true }) };
});
vi.mock("next/image", () => ({
  // eslint-disable-next-line @next/next/no-img-element
  default: ({ src, alt }: { src: string; alt: string }) => <img src={src} alt={alt} />,
}));

import ResolverPlayer from "@/components/player/ResolverPlayer";
import SourceMenu from "@/components/player/SourceMenu";
import { SettingsProvider } from "@/components/SettingsProvider";
import * as resolve from "@/lib/resolve";
import type { ResolveState, StreamState } from "@/lib/resolve";
import { DEFAULT_SETTINGS } from "@/lib/settings";
import type { PlaybackSource } from "@/lib/playback";

const stream = (id: string, quality: string, over: Partial<StreamState> = {}): StreamState => ({
  stream_id: id, quality, rank: parseInt(quality) || 0, state: "idle", progress: null, duration_seconds: null, library_id: null, play_url: null, error: null, ...over,
});
const state = (over: Partial<ResolveState> = {}): ResolveState => ({
  task_id: "tsk_1", status: "running", version: 1, sources_total: 2, sources_done: 1, queue_position: null, has_more: false,
  sources: [{ name: "Vertex", starred: true, status: "ok", error: null, streams: [stream("b", "800p"), stream("a", "534p")] }],
  subtitles: [], auto_stream_id: null, ...over,
});
const withDownload = (over: Partial<StreamState>): ResolveState =>
  state({
    auto_stream_id: "b",
    sources: [{ name: "Vertex", starred: true, status: "ok", error: null, streams: [stream("b", "800p", { state: "downloading", progress: 10, play_url: "/api/resolve/relay?u=B" }), stream("a", "534p", over)] }],
  });

const source: PlaybackSource = { source_type: "resolver", url: "", subtitles: [], resume_position_seconds: null, video_settings: {} };
const identity = { tmdbId: 550, mediaType: "movie" as const };

beforeEach(() => {
  vi.clearAllMocks();
  hlsInstances.length = 0;
  Object.defineProperty(HTMLMediaElement.prototype, "readyState", { configurable: true, get: () => 4 });
  Object.defineProperty(HTMLMediaElement.prototype, "duration", { configurable: true, get: () => 100 });
  HTMLMediaElement.prototype.play = vi.fn().mockResolvedValue(undefined) as never;
  HTMLMediaElement.prototype.pause = vi.fn();
  HTMLMediaElement.prototype.load = vi.fn();
  vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, text: async () => "" }));
});
afterEach(() => vi.unstubAllGlobals());

function mount() {
  return render(
    <SettingsProvider initial={{ ...DEFAULT_SETTINGS, playback: { ...DEFAULT_SETTINGS.playback, autoplay_on_open: false } }}>
      <ResolverPlayer source={source} title="Fight Club" identity={identity} backHref="/movie/550" artwork="https://image.tmdb.org/t/p/w1280/x.jpg" />
    </SettingsProvider>
  );
}

describe("when the video breaks while playing", () => {
  it("asks the server to start again (same source if it did not fail), at most 3 times", async () => {
    const playing = state({
      auto_stream_id: "b", status: "done",
      sources: [{ name: "Vertex", starred: true, status: "ok", error: null, streams: [stream("b", "800p", { state: "ready", progress: 100, play_url: "/api/resolve/relay?u=B", library_id: "lib_1" })] }],
    });
    vi.mocked(resolve.startResolve).mockResolvedValue(playing);
    vi.mocked(resolve.getResolveState).mockResolvedValue(playing);
    vi.mocked(resolve.requestDownload).mockResolvedValue(playing);
    mount();
    await waitFor(() => expect(hlsInstances.length).toBe(1));
    const onErr = hlsInstances[0].on.mock.calls.find((c) => c[0] === "e")![1];
    await act(async () => {
      for (let i = 0; i < 5; i++) onErr("e", { fatal: true, type: "n" }); // retries are used up, then it gives up
    });
    await waitFor(() => expect(resolve.requestDownload).toHaveBeenCalledWith("tsk_1", null));
    expect(resolve.requestDownload).toHaveBeenCalledTimes(1);
  });
});

describe("when the file is deleted while playing (404 on a piece)", () => {
  it("starts again at once, without waiting for hls.js to give up", async () => {
    const playing = state({
      auto_stream_id: "b", status: "done",
      sources: [{ name: "Vertex", starred: true, status: "ok", error: null, streams: [stream("b", "800p", { state: "ready", progress: 100, play_url: "/api/resolve/relay?u=B", library_id: "lib_1" })] }],
    });
    vi.mocked(resolve.startResolve).mockResolvedValue(playing);
    vi.mocked(resolve.getResolveState).mockResolvedValue(playing);
    vi.mocked(resolve.requestDownload).mockResolvedValue(playing);
    mount();
    await waitFor(() => expect(hlsInstances.length).toBe(1));
    const onErr = hlsInstances[0].on.mock.calls.find((c) => c[0] === "e")![1];
    await act(async () => {
      onErr("e", { fatal: false, type: "n", details: "fragLoadError", response: { code: 404 } });
      onErr("e", { fatal: false, type: "n", details: "fragLoadError", response: { code: 404 } });
    });
    await waitFor(() => expect(resolve.requestDownload).toHaveBeenCalledWith("tsk_1", null));
    expect(resolve.requestDownload).toHaveBeenCalledTimes(1);
  });

  it("carries on from the second it stopped at, not from the beginning (hls.js resets the video on destroy)", async () => {
    const playing = state({
      auto_stream_id: "b", status: "done",
      sources: [{ name: "Vertex", starred: true, status: "ok", error: null, streams: [stream("b", "800p", { state: "ready", progress: 100, play_url: "/api/resolve/relay?u=B", library_id: "lib_1" })] }],
    });
    vi.mocked(resolve.startResolve).mockResolvedValue(playing);
    vi.mocked(resolve.getResolveState).mockResolvedValue(playing);
    vi.mocked(resolve.requestDownload).mockResolvedValue(playing);
    let cur = 73;
    const sets: number[] = [];
    Object.defineProperty(HTMLMediaElement.prototype, "currentTime", { configurable: true, get: () => cur, set: (v: number) => { sets.push(v); cur = v; } });
    mount();
    await waitFor(() => expect(hlsInstances.length).toBe(1));
    hlsInstances[0].destroy.mockImplementation(() => { cur = 0; });
    const onErr = hlsInstances[0].on.mock.calls.find((c) => c[0] === "e")![1];
    await act(async () => {
      onErr("e", { fatal: false, type: "n", response: { code: 404 } });
    });
    await waitFor(() => expect(hlsInstances.length).toBe(2)); // the player started again
    const video = document.querySelector("video") as HTMLVideoElement;
    await act(async () => {
      fireEvent(video, new Event("durationchange"));
      fireEvent(video, new Event("loadedmetadata"));
    });
    expect(sets).toContain(73);
    delete (HTMLMediaElement.prototype as unknown as Record<string, unknown>).currentTime;
  });
});

describe("SourceMenu", () => {
  const picker = (over = {}) => ({
    sources: withDownload({ state: "downloading", progress: 42, play_url: null }).sources,
    playingId: "b", searching: false, onSelect: vi.fn(), ...over,
  });

  it("lists sources and qualities with the progress filling the row", () => {
    render(<SourceMenu picker={picker()} getTime={() => 12} />);
    fireEvent.click(screen.getByLabelText("Sources and quality"));
    expect(screen.getByText("Vertex")).toBeInTheDocument();
    expect(screen.getByText("42%")).toBeInTheDocument();
    expect(screen.getByLabelText(/^800p, playing/)).toHaveAttribute("aria-current", "true");
    const fills = screen.getAllByTestId("source-fill");
    expect(fills.some((f) => f.style.width === "42%")).toBe(true);
  });

  it("a click reports the stream and where the video is", () => {
    const p = picker();
    render(<SourceMenu picker={p} getTime={() => 77} />);
    fireEvent.click(screen.getByLabelText("Sources and quality"));
    fireEvent.click(screen.getByLabelText(/^534p/));
    expect(p.onSelect).toHaveBeenCalledWith("a", 77, 0);
  });

  it("lists the sources on the left, even when there is only one, and switches the qualities shown", () => {
    const two = [
      ...picker().sources,
      { name: "Other", starred: false, status: "ok", error: null, streams: [stream("e", "1080p")] },
    ];
    const { unmount } = render(<SourceMenu picker={picker({ sources: [picker().sources[0]] })} getTime={() => 0} />);
    fireEvent.click(screen.getByLabelText("Sources and quality"));
    expect(screen.getByRole("tab", { name: /Vertex/ })).toHaveAttribute("aria-selected", "true");
    unmount();
    render(<SourceMenu picker={picker({ sources: two })} getTime={() => 0} />);
    fireEvent.click(screen.getByLabelText("Sources and quality"));
    expect(screen.queryByLabelText(/^1080p/)).toBeNull();
    fireEvent.click(screen.getByRole("tab", { name: /Other/ }));
    expect(screen.getByLabelText(/^1080p/)).toBeInTheDocument();
    expect(screen.queryByLabelText(/^534p/)).toBeNull();
  });

  it("says when it is still searching and when nothing is there yet", () => {
    render(<SourceMenu picker={picker({ sources: [], searching: true })} getTime={() => 0} />);
    fireEvent.click(screen.getByLabelText("Sources and quality"));
    expect(screen.getByText("No sources yet…")).toBeInTheDocument();
    expect(screen.getByText("Still looking for more sources…")).toBeInTheDocument();
  });
});

describe("ResolverPlayer", () => {
  it("shows the loading screen with the artwork, then the video as HLS", async () => {
    vi.mocked(resolve.startResolve).mockResolvedValue(state());
    vi.mocked(resolve.requestDownload).mockResolvedValue(withDownload({}));
    vi.mocked(resolve.getResolveState).mockImplementation(() => new Promise(() => {}));
    const { container } = mount();
    expect(screen.getByTestId("player-loading")).toHaveAttribute("data-phase", "finding");
    expect(container.querySelector("img")).toHaveAttribute("src", "https://image.tmdb.org/t/p/w1280/x.jpg");
    await waitFor(() => expect(container.querySelector("video")).not.toBeNull());
    expect(resolve.requestDownload).toHaveBeenCalledWith("tsk_1", null); // the first answer had no download yet
    expect(container.querySelector("video")).not.toHaveAttribute("src");
    await waitFor(() => expect(hlsInstances.length).toBe(1));
    expect(hlsInstances[0].loadSource).toHaveBeenCalledWith(expect.stringContaining("/api/resolve/relay?u=B"));
    expect(screen.getByLabelText("Sources and quality")).toBeInTheDocument();
  });

  it("says when the search is waiting in line", async () => {
    vi.mocked(resolve.startResolve).mockResolvedValue(state({ sources: [], queue_position: 2 }));
    vi.mocked(resolve.getResolveState).mockImplementation(() => new Promise(() => {}));
    mount();
    expect(await screen.findByText("Waiting in line (2)…")).toBeInTheDocument();
  });

  it("says so when nothing was found, and tries again", async () => {
    vi.mocked(resolve.startResolve).mockResolvedValue(state({ status: "done", sources: [] }));
    mount();
    await waitFor(() => expect(screen.getByTestId("player-loading")).toHaveAttribute("data-phase", "failed"));
    expect(screen.getByText(/couldn't get a video/)).toBeInTheDocument();
    fireEvent.click(screen.getByText("Try again"));
    await waitFor(() => expect(resolve.startResolve).toHaveBeenCalledTimes(2));
  });

  it("a service error shows up as a failure with its message", async () => {
    vi.mocked(resolve.startResolve).mockRejectedValue(new Error("The video service isn't reachable right now."));
    mount();
    await waitFor(() => expect(screen.getByText("The video service isn't reachable right now.")).toBeInTheDocument());
  });

  it("clicking an idle quality starts its download and keeps playing; clicking it once playable switches", async () => {
    vi.mocked(resolve.startResolve).mockResolvedValue(withDownload({}));
    vi.mocked(resolve.getResolveState).mockImplementation(() => new Promise(() => {}));
    vi.mocked(resolve.requestDownload).mockResolvedValue(withDownload({ state: "downloading", progress: 0, play_url: null }));
    const { container } = mount();
    await waitFor(() => expect(container.querySelector("video")).not.toBeNull());

    fireEvent.click(screen.getByLabelText("Sources and quality"));
    fireEvent.click(screen.getByLabelText(/^534p/));
    expect(resolve.requestDownload).toHaveBeenCalledWith("tsk_1", "a");
    await waitFor(() => expect(screen.getByLabelText(/^534p, downloading/)).toBeInTheDocument());
    expect(hlsInstances.length).toBe(1); // still the first video

    // it becomes playable (the next poll), another click plays it
    vi.mocked(resolve.getResolveState).mockResolvedValue(withDownload({ state: "downloading", progress: 8, play_url: "/api/resolve/relay?u=A" }));
    await act(async () => {
      await new Promise((r) => setTimeout(r, 1700));
    });
    fireEvent.click(screen.getByLabelText(/^534p, downloading 8 percent, click to play/));
    await waitFor(() => expect(hlsInstances.length).toBe(2));
    expect(hlsInstances[1].loadSource).toHaveBeenCalledWith(expect.stringContaining("relay?u=A"));
    expect(hlsInstances[0].destroy).toHaveBeenCalled();
  }, 15000);

  it("adds the resolver's subtitles to the player", async () => {
    vi.mocked(resolve.startResolve).mockResolvedValue({
      ...withDownload({}),
      subtitles: [{ language: "en", label: "English", url: "/api/resolve/relay?u=S", format: "vtt", source: "Vertex", default: false }],
    });
    vi.mocked(resolve.getResolveState).mockImplementation(() => new Promise(() => {}));
    const { container } = mount();
    await waitFor(() => expect(container.querySelector("video")).not.toBeNull());
    fireEvent.click(screen.getByLabelText("Settings"));
    fireEvent.click(screen.getByText("Subtitles"));
    expect(await screen.findByText(/English · Vertex/)).toBeInTheDocument();
  });
});


describe("Load more sources", () => {
  it("the menu offers 'Load more sources', then 'Load all sources', and hides it when none are left", async () => {
    const done = state({ status: "done", has_more: true, auto_stream_id: "b", sources: withDownload({}).sources });
    vi.mocked(resolve.startResolve).mockResolvedValue(done);
    vi.mocked(resolve.getResolveState).mockResolvedValue(done);
    vi.mocked(resolve.loadMoreSources)
      .mockResolvedValueOnce({ ...done, has_more: true, status: "done", version: 2 })
      .mockResolvedValueOnce({ ...done, has_more: false, version: 3 });
    mount();
    fireEvent.click(await screen.findByLabelText("Sources and quality"));
    fireEvent.click(await screen.findByRole("button", { name: /^\+?\s*Load more$/ }));
    await waitFor(() => expect(resolve.loadMoreSources).toHaveBeenLastCalledWith("tsk_1", false));
    fireEvent.click(await screen.findByRole("button", { name: /^\+?\s*Load all$/ }));
    await waitFor(() => expect(resolve.loadMoreSources).toHaveBeenLastCalledWith("tsk_1", true));
    await waitFor(() => expect(screen.queryByRole("button", { name: /Load (more|all)$/ })).toBeNull());
  });

  it("is not shown when there is nothing more to ask", () => {
    const picker = { sources: withDownload({}).sources, playingId: "b", searching: false, onSelect: vi.fn(), more: null };
    render(<SourceMenu picker={picker} getTime={() => 0} />);
    fireEvent.click(screen.getByLabelText("Sources and quality"));
    expect(screen.queryByRole("button", { name: /Load (more|all)$/ })).toBeNull();
  });

  it("is disabled while the search is still running", () => {
    const picker = { sources: withDownload({}).sources, playingId: "b", searching: true, onSelect: vi.fn(), more: { step: 0 as const, loading: false, onClick: vi.fn() } };
    render(<SourceMenu picker={picker} getTime={() => 0} />);
    fireEvent.click(screen.getByLabelText("Sources and quality"));
    expect(screen.getByRole("button", { name: /^\+?\s*Load more$/ })).toBeDisabled();
  });
});


describe("sources without video", () => {
  it("are shown disabled and can't be opened", () => {
    const sources = [
      { name: "Vertex", starred: true, status: "ok", error: null, streams: [stream("b", "800p")] },
      { name: "Empty", starred: false, status: "ok", error: null, streams: [] },
    ];
    render(<SourceMenu picker={{ sources, playingId: null, searching: false, onSelect: vi.fn(), more: null }} getTime={() => 0} />);
    fireEvent.click(screen.getByLabelText("Sources and quality"));
    expect(screen.getByRole("tab", { name: "Empty" })).toBeDisabled();
    expect(screen.getByRole("tab", { name: /Vertex/ })).not.toBeDisabled();
    expect(screen.getByText("800p")).toBeInTheDocument(); // the first source with video is the one shown
  });
});

"use client";

import { useEffect, useState } from "react";
import { addToWatchlist, getWatchlistStatus, removeFromWatchlist } from "@/lib/watchlist";
import { getLatestTVWatchProgress, type WatchProgress } from "@/lib/playback";
import { showToast } from "@/lib/toast";
import type { MediaType } from "@/lib/media";
import { useBoxName } from "@/components/BoxNameProvider";
import TitleLikeButton from "@/components/opinions/TitleLikeButton";
import LikedByLine from "@/components/opinions/LikedByLine";
import DiscussionButton from "@/components/opinions/DiscussionButton";
import { useTitleLikes } from "@/lib/title-likes";

// Sizing tiers, driven by the width of the space the buttons actually
// get (a container query, not the viewport) — the TV detail page's
// poster, the hero's padding and the phone layout all change that width
// differently, so the viewport alone can't tell us. Each tier only
// shrinks the buttons when the row would otherwise wrap:
//   big     16px text, 20px side padding  (the original look)
//   compact 15px, 16px padding
//   tight   14px, 12px padding
//   stack   below "tight": two equal full-width rows, still big — an
//           intentional layout instead of an accidental wrap.
// The two buttons always share one width (auto-cols-fr) and one height.
// Thresholds are the measured width of the equal-width pair plus a few
// px of safety, and depend on how wide the resume chip makes Watch Now
// ("S1:E8" vs "S10:E12"), so they come in three sets. Tailwind needs the
// full class strings literally, hence the repetition.
// Three columns when the heart is shown: Watch Now and Add to box share the space, the heart is just wide enough
// for its icon once the buttons sit in a row (stacked on a narrow phone it spans the full width, with its label).
const GRID_BY_LABEL = {
  none: "grid gap-3 text-base [--pad:1.25rem] @[324px]:w-fit @[324px]:grid-flow-col @[324px]:auto-cols-fr @[324px]:text-sm @[324px]:[--pad:0.75rem] @[358px]:text-[15px] @[358px]:[--pad:1rem] @[392px]:text-base @[392px]:[--pad:1.25rem]",
  short:
    "grid gap-3 text-base [--pad:1.25rem] @[360px]:w-fit @[360px]:grid-flow-col @[360px]:auto-cols-fr @[360px]:text-sm @[360px]:[--pad:0.75rem] @[408px]:text-[15px] @[408px]:[--pad:1rem] @[452px]:text-base @[452px]:[--pad:1.25rem]",
  long: "grid gap-3 text-base [--pad:1.25rem] @[388px]:w-fit @[388px]:grid-flow-col @[388px]:auto-cols-fr @[388px]:text-sm @[388px]:[--pad:0.75rem] @[438px]:text-[15px] @[438px]:[--pad:1rem] @[484px]:text-base @[484px]:[--pad:1.25rem]",
} as const;

// With a heart the container needs 60px more before the buttons can share a row, and the heart's column is "auto".
const GRID_WITH_HEART_BY_LABEL = {
  none: "grid gap-3 text-base [--pad:1.25rem] @[444px]:w-fit @[444px]:grid-flow-col @[444px]:[grid-template-columns:1fr_1fr_auto] @[444px]:text-sm @[444px]:[--pad:0.75rem] @[478px]:text-[15px] @[478px]:[--pad:1rem] @[512px]:text-base @[512px]:[--pad:1.25rem]",
  short:
    "grid gap-3 text-base [--pad:1.25rem] @[480px]:w-fit @[480px]:grid-flow-col @[480px]:[grid-template-columns:1fr_1fr_auto] @[480px]:text-sm @[480px]:[--pad:0.75rem] @[528px]:text-[15px] @[528px]:[--pad:1rem] @[572px]:text-base @[572px]:[--pad:1.25rem]",
  long: "grid gap-3 text-base [--pad:1.25rem] @[508px]:w-fit @[508px]:grid-flow-col @[508px]:[grid-template-columns:1fr_1fr_auto] @[508px]:text-sm @[508px]:[--pad:0.75rem] @[558px]:text-[15px] @[558px]:[--pad:1rem] @[604px]:text-base @[604px]:[--pad:1.25rem]",
} as const;
// The point (per label size) at which the grid above becomes a row, where the heart drops its text.
const HEART_ROW_LABEL = {
  none: "@[444px]:sr-only",
  short: "@[480px]:sr-only",
  long: "@[508px]:sr-only",
} as const;
const HEART_ROW_FLEX = {
  none: "@[444px]:flex-none @[444px]:min-w-12 @[444px]:px-3",
  short: "@[480px]:flex-none @[480px]:min-w-12 @[480px]:px-3",
  long: "@[508px]:flex-none @[508px]:min-w-12 @[508px]:px-3",
} as const;

const BUTTON_BASE =
  "flex h-12 items-center justify-center gap-2 whitespace-nowrap rounded-xl px-[var(--pad)] font-semibold";

export default function DetailActions({
  tmdbId,
  mediaType,
  tvProgress,
  title,
}: {
  tmdbId: number;
  mediaType: MediaType;
  // Detail pages pass the title: that turns on the heart, "<people> liked this" and the Discussion button
  // (the home hero doesn't, so it stays as it was).
  title?: string;
  // TV only: the show's latest saved progress. The TV detail page
  // resolves it server-side and passes it in (a value, or null for
  // "never started"), so there's no loading flash and no duplicate
  // fetch alongside SeasonBrowser. Left undefined (the home hero, which
  // has no such page around it) the component looks it up itself.
  tvProgress?: WatchProgress | null;
}) {
  const scope = { media_type: mediaType, tmdb_id: tmdbId } as const;
  const { enabled: socialLoaded } = useTitleLikes(scope, title !== undefined);
  const socialOn = title !== undefined && socialLoaded;
  const [fetchedProgress, setFetchedProgress] = useState<WatchProgress | null | undefined>(undefined);
  useEffect(() => {
    if (mediaType !== "tv" || tvProgress !== undefined) return;
    let cancelled = false;
    getLatestTVWatchProgress(tmdbId)
      .then((p) => {
        if (!cancelled) setFetchedProgress(p);
      })
      .catch(() => {
        // Can't resolve history — Watch Now just starts at S1:E1.
        if (!cancelled) setFetchedProgress(null);
      });
    return () => {
      cancelled = true;
    };
  }, [mediaType, tmdbId, tvProgress]);
  const progress = tvProgress !== undefined ? tvProgress : fetchedProgress;

  // null = not resolved yet — the button stays disabled rather than
  // guessing "not in the list" while the real status is still loading,
  // which would otherwise let a click race the actual answer.
  const [inCandyBox, setInCandyBox] = useState<boolean | null>(null);
  const [pending, setPending] = useState(false);
  const boxName = useBoxName();

  useEffect(() => {
    let cancelled = false;
    getWatchlistStatus(mediaType, tmdbId)
      .then((status) => {
        if (!cancelled) setInCandyBox(status);
      })
      .catch(() => {
        if (!cancelled) setInCandyBox(false);
      });
    return () => {
      cancelled = true;
    };
  }, [mediaType, tmdbId]);

  async function toggleCandyBox() {
    if (inCandyBox === null || pending) return;
    setPending(true);
    try {
      if (inCandyBox) {
        await removeFromWatchlist(mediaType, tmdbId);
        setInCandyBox(false);
      } else {
        await addToWatchlist(mediaType, tmdbId);
        setInCandyBox(true);
      }
    } catch {
      // The button stays at its last known-good state (nothing changed),
      // but say so — otherwise a tap that did nothing looks broken.
      showToast(
        inCandyBox
          ? `Couldn't remove it from ${boxName}. Please try again.`
          : `Couldn't add it to ${boxName}. Please try again.`
      );
    } finally {
      setPending(false);
    }
  }

  // Watch Now is never a dead end. A movie goes straight to its
  // player; TV resumes at the remembered episode if there's any
  // history, otherwise starts at S1E1.
  const resumeLabel =
    mediaType === "tv" && progress?.season_number != null && progress?.episode_number != null
      ? `S${progress.season_number}:E${progress.episode_number}`
      : null;
  const watchHref =
    mediaType === "movie"
      ? `/watch/movie/${tmdbId}`
      : resumeLabel
        ? `/watch/tv/${tmdbId}/${progress!.season_number}/${progress!.episode_number}`
        : `/watch/tv/${tmdbId}/1/1`;
  const labelSize = !resumeLabel ? "none" : resumeLabel.length <= 5 ? "short" : "long";

  return (
    // The outer block is the size-measuring container; the grid inside
    // is what actually resizes (a container can't restyle itself).
    <div className="@container w-full">
      <div className={(socialOn ? GRID_WITH_HEART_BY_LABEL : GRID_BY_LABEL)[labelSize]}>
        <a
          href={watchHref}
          className={`${BUTTON_BASE} bg-accent text-on-accent hover:bg-accent/90 ${
            resumeLabel ? "pr-[calc(var(--pad)_-_0.5rem)]" : ""
          }`}
        >
          <svg className="h-[1.1em] w-[1.1em] shrink-0" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <path d="M8 5v14l11-7z" />
          </svg>
          Watch Now
          {/* A solid dark rounded-rectangle chip: dark-on-pink was once
              "lost in the box colour", so it stays a high-contrast
              chip. It sits one small gap from the text, and its size is
              relative to the font (em) so it can't make the button
              taller than the fixed h-12. */}
          {resumeLabel && (
            <span className="rounded-md bg-canvas px-2 py-1 text-[0.8em] font-semibold leading-none text-white">
              {resumeLabel}
            </span>
          )}
        </a>
        <button
          onClick={toggleCandyBox}
          disabled={inCandyBox === null || pending}
          aria-pressed={inCandyBox === true}
          className={`${BUTTON_BASE} border transition-colors disabled:cursor-not-allowed ${
            inCandyBox
              ? "border-accent bg-accent/10 text-accent hover:bg-accent/20 disabled:opacity-70"
              : "border-white/15 text-white/80 hover:border-white/30 hover:text-white disabled:opacity-50"
          }`}
        >
          {inCandyBox ? `✓ In ${boxName}` : `Add to ${boxName}`}
        </button>
        {title !== undefined && (
          // The heart and the discussion icon are one block, split by a thin line.
          <div className="flex h-12 divide-x divide-white/15 overflow-hidden rounded-xl border border-white/15">
            <TitleLikeButton scope={scope} variant="segment" className={`flex-1 px-[var(--pad)] ${HEART_ROW_FLEX[labelSize]}`} labelClass={HEART_ROW_LABEL[labelSize]} />
            <DiscussionButton scope={scope} title={title} variant="segment" />
          </div>
        )}
      </div>
      {socialOn && (
        <LikedByLine scope={scope} className="mt-3" />
      )}
    </div>
  );
}

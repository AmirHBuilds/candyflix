"use client";

import FadeImage from "@/components/FadeImage";
import Link from "next/link";
import { useSettings } from "@/components/SettingsProvider";
import { detailHref, posterUrl, type MediaItem } from "@/lib/media";

export default function MediaCard({
  item,
  onNavigate,
  href,
  badge,
}: {
  item: MediaItem;
  onNavigate?: () => void;
  /** Overrides the default detail-page link — used by Continue Watching
   * (Phase 7) to send the click straight to the resume point instead of
   * the detail page, same as every other row's default behavior. */
  href?: string;
  /** Small corner label over the poster, e.g. "S2:E8" — Continue
   * Watching's series items only; omitted everywhere else. */
  badge?: string;
}) {
  const { show_ratings, show_years } = useSettings().settings.appearance;
  const poster = posterUrl(item.poster_path, "w500");
  const typeLabel = item.media_type === "movie" ? "Movie" : "TV";

  return (
    <Link href={href ?? detailHref(item)} onClick={onNavigate} className="group block w-full min-w-0">
      <div className="relative aspect-[2/3] overflow-hidden rounded-xl bg-white/5 ring-1 ring-white/10 transition-all duration-200 group-hover:ring-accent/50 group-hover:shadow-[0_0_24px_-4px_color-mix(in_srgb,var(--color-accent)_35%,transparent)]">
        {poster ? (
          <FadeImage
            src={poster}
            alt={item.title}
            fill
            sizes="(min-width: 1024px) 16vw, (min-width: 640px) 25vw, 50vw"
            className="object-cover group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full items-center justify-center px-3 text-center text-sm text-white/40">
            {item.title}
          </div>
        )}
        {badge && (
          <span className="absolute left-2 top-2 rounded-md bg-black/70 px-2 py-0.5 text-[11px] font-medium text-white/90 backdrop-blur-sm">
            {badge}
          </span>
        )}
      </div>
      <p className="mt-2 truncate text-sm text-white/80">{item.title}</p>
      <div className="flex items-center justify-between text-xs text-white/40">
        <span className="truncate">
          {show_years ? `${item.year ?? "—"} · ${typeLabel}` : typeLabel}
        </span>
        {show_ratings && item.rating != null && (
          <span className="ml-2 shrink-0 text-highlight">★ {item.rating.toFixed(1)}</span>
        )}
      </div>
    </Link>
  );
}

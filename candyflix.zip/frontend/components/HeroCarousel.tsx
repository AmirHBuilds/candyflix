"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { backdropUrl, detailHref, overviewForLength, type MediaItem } from "@/lib/media";
import { useSettings } from "@/components/SettingsProvider";
import DetailActions from "@/components/DetailActions";
import HeroSocial from "@/components/opinions/HeroSocial";
import { getBannerSocial, type FeedTitle } from "@/lib/opinions";

const MAX_SLIDES = 5;
const SWIPE_THRESHOLD_PX = 40;

export default function HeroCarousel({ items }: { items: MediaItem[] }) {
  const { settings } = useSettings();
  const { hero_enabled, hero_description, hero_interval_seconds, description_length } = settings.appearance;
  const rotateMs = hero_interval_seconds * 1000;
  const slides = hero_enabled ? items.slice(0, MAX_SLIDES) : [];
  const [index, setIndex] = useState(0);
  // Who liked / said what about each slide's title (nothing when it's switched off or nobody has).
  const [social, setSocial] = useState<Record<string, FeedTitle>>({});
  const slideKeys = slides.map((s) => `${s.media_type}:${s.tmdb_id}`).join(",");
  useEffect(() => {
    if (!slideKeys) return;
    let live = true;
    getBannerSocial(slides.map((s) => ({ media_type: s.media_type, tmdb_id: s.tmdb_id })))
      .then((f) => live && f.enabled && setSocial(Object.fromEntries(f.items.map((i) => [`${i.media_type}:${i.tmdb_id}`, i]))))
      .catch(() => {});
    return () => {
      live = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slideKeys]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const touchStartX = useRef<number | null>(null);

  function resetTimer() {
    if (timerRef.current) clearInterval(timerRef.current);
    if (slides.length > 1) {
      timerRef.current = setInterval(() => {
        setIndex((i) => (i + 1) % slides.length);
      }, rotateMs);
    }
  }

  useEffect(() => {
    resetTimer();
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slides.length, rotateMs]);

  function goTo(i: number) {
    setIndex(((i % slides.length) + slides.length) % slides.length);
    resetTimer();
  }

  function handleTouchStart(e: React.TouchEvent) {
    touchStartX.current = e.touches[0].clientX;
  }

  function handleTouchEnd(e: React.TouchEvent) {
    if (touchStartX.current === null) return;
    const delta = e.changedTouches[0].clientX - touchStartX.current;
    if (delta > SWIPE_THRESHOLD_PX) goTo(index - 1);
    else if (delta < -SWIPE_THRESHOLD_PX) goTo(index + 1);
    touchStartX.current = null;
  }

  if (slides.length === 0) return null;

  return (
    <section
      className="relative -mx-6 h-[75dvh] min-h-[460px] overflow-hidden sm:mx-0 sm:rounded-3xl sm:min-h-[560px]"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {slides.map((item, i) => {
        const backdrop = backdropUrl(item.backdrop_path, "original");
        const isActive = i === index;
        const typeLabel = item.media_type === "movie" ? "Movie" : "TV";
        return (
          <div
            key={`${item.media_type}-${item.tmdb_id}`}
            aria-hidden={!isActive}
            className={`absolute inset-0 transition-opacity duration-700 ease-out ${
              isActive ? "opacity-100" : "pointer-events-none opacity-0"
            }`}
          >
            {backdrop && (
              <Image
                src={backdrop}
                alt=""
                fill
                priority={i === 0}
                sizes="100vw"
                className="object-cover object-top"
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-canvas via-canvas/55 to-canvas/10" />
            <div className="absolute inset-x-0 bottom-0 p-6 sm:p-12">
              <p className="mb-2 text-sm font-medium uppercase tracking-wide text-highlight">
                Trending Now · {typeLabel} · {item.year ?? ""}
              </p>
              <Link href={detailHref(item)} className="group inline-block">
                <p className="mb-3 max-w-2xl font-[family-name:var(--font-display)] text-4xl font-semibold italic text-white group-hover:underline sm:text-6xl">
                  {item.title}
                </p>
              </Link>
              {/* A short synopsis under the title. Clamped to two lines on
                  phones (the banner is tall but not endless) and three
                  from sm up; the text is already trimmed to a sentence. */}
              {hero_description && item.overview && (
                <p
                  className={`mb-5 max-w-xl text-sm text-white/75 [text-shadow:0_1px_8px_rgb(0_0_0/0.6)] sm:text-base ${
                    description_length === "full" ? "line-clamp-6" : "line-clamp-2 sm:line-clamp-3"
                  }`}
                >
                  {overviewForLength(item.overview, description_length, 180)}
                </p>
              )}
              {isActive && <HeroSocial key={`${item.media_type}-${item.tmdb_id}`} social={social[`${item.media_type}:${item.tmdb_id}`]} />}
              <DetailActions tmdbId={item.tmdb_id} mediaType={item.media_type} />
            </div>
          </div>
        );
      })}

      {slides.length > 1 && (
        <>
          <button
            type="button"
            aria-label="Previous title"
            onClick={() => goTo(index - 1)}
            className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-black/30 p-2 text-white/80 backdrop-blur hover:bg-black/50"
          >
            ‹
          </button>
          <button
            type="button"
            aria-label="Next title"
            onClick={() => goTo(index + 1)}
            className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-black/30 p-2 text-white/80 backdrop-blur hover:bg-black/50"
          >
            ›
          </button>

          <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 gap-2">
            {slides.map((_, i) => (
              <button
                type="button"
                key={i}
                aria-label={`Go to slide ${i + 1}`}
                onClick={() => goTo(i)}
                className={`h-1.5 rounded-full transition-all ${
                  i === index ? "w-6 bg-accent" : "w-1.5 bg-white/30"
                }`}
              />
            ))}
          </div>
        </>
      )}
    </section>
  );
}

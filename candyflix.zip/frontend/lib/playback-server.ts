import { cookies } from "next/headers";
import { getApiBaseUrl, fetchWithTimeout } from "@/lib/api-client";
import type { PlaybackSource, WatchProgress } from "@/lib/playback";

/**
 * Server-side counterpart to lib/playback.ts's fetchers. A Server
 * Component's fetch() runs in Node, which has no browser cookie jar —
 * credentials:"include" does nothing there. We read the incoming
 * request's cookies via next/headers and forward them explicitly,
 * exactly like getServerCurrentUser() in lib/session.ts already does.
 * These are the only playback fetchers safe to call from a Server
 * Component (the watch pages); everything in lib/playback.ts is
 * client-only.
 */
async function forwardedCookieHeader(): Promise<string> {
  const store = await cookies();
  return store.toString();
}

async function handle<T>(res: Response, fallbackMessage: string): Promise<T> {
  if (!res.ok) {
    let detail = fallbackMessage;
    try {
      const body = await res.json();
      if (body?.detail) detail = body.detail;
    } catch {
      // ignore — use fallback
    }
    throw new Error(detail);
  }
  return res.json();
}

export async function getMoviePlaybackSourceServer(
  tmdbId: number | string
): Promise<PlaybackSource> {
  const res = await fetchWithTimeout(`${getApiBaseUrl()}/playback/movie/${tmdbId}`, {
    headers: { Cookie: await forwardedCookieHeader() },
    cache: "no-store",
  });
  return handle(res, "Playback isn't available right now.");
}

export async function getEpisodePlaybackSourceServer(
  tmdbId: number | string,
  season: number,
  episode: number
): Promise<PlaybackSource> {
  const res = await fetchWithTimeout(`${getApiBaseUrl()}/playback/tv/${tmdbId}/${season}/${episode}`, {
    headers: { Cookie: await forwardedCookieHeader() },
    cache: "no-store",
  });
  return handle(res, "Playback isn't available right now.");
}

/**
 * Backs the TV detail page: fetched once, server-side, and passed down
 * to both DetailActions (the "Watch Now" button + its resume label) and
 * SeasonBrowser (which episode's name to show in pink) so the two don't
 * each make their own client-side round-trip for the same answer, and
 * neither has to render a disabled/unhighlighted flash while loading —
 * unlike the Candy Box status, which is genuinely per-widget and stays
 * a client-side fetch in DetailActions.
 */
export async function getLatestTVWatchProgressServer(
  tmdbId: number | string
): Promise<WatchProgress | null> {
  const res = await fetchWithTimeout(`${getApiBaseUrl()}/watch-progress/tv/${tmdbId}/latest`, {
    headers: { Cookie: await forwardedCookieHeader() },
    cache: "no-store",
  });
  return handle(res, "Couldn't load watch progress.");
}

# CandyFlix

A small, private movie & TV app — built for Candy, and the people close to her.

CandyFlix uses TMDB for metadata and pluggable playback source providers
for streaming. It's intentionally simple: a handful of trusted users, no
enterprise auth, no generic "streaming platform" chrome.

## Status

**Phases 1–7 complete** (through Continue Watching and TV resume/progress,
plus the seven follow-up UI updates). Summary of everything built so far:

- Phases 2–4: auth, TMDB integration, browsing/search UX, visual polish.
- **Phase 5a** — real custom video player (custom-built controls, not
  the browser's native ones) against local mock video files, with
  resume-watching (`WatchProgress` model) and subtitle rendering.
- **Phase 5b** — online subtitle discovery via the OpenSubtitles REST
  API: auto-fetches a default English subtitle for every title,
  plus in-player language search/browse. `mock-subtitles/` is
  deprecated and unused as of this phase.
- **Phase 5c** — player polish: remembered volume/mute/subtitle-language
  preferences across sessions, cross-season next/previous-episode
  rollover, a sleep timer, and various player UI fixes (icon-by-level
  volume icon, settings-menu positioning that survives fullscreen and
  small mobile viewports).
- **Phase 6** — watchlist ("Candy Box"): add/remove/list a title,
  wired up on both detail pages and the home page's hero carousel.
- **Phase 7** — Continue Watching row on the home page (movies + series,
  furthest-episode resume), TV resume/"In progress" episode highlighting,
  instant episode navigation with a one-shot resume hint in the URL.

See `PHASE_HANDOFF.md` (if present in the repo root) for the full
architecture write-up, open issues, and conventions established along
the way — it's kept up to date as the authoritative project handoff
document across chat sessions.

## Stack

- **Backend:** FastAPI, SQLAlchemy (async), PostgreSQL, Redis, Alembic
- **Frontend:** Next.js (App Router), TypeScript, Tailwind CSS
- **Infra:** Docker Compose for local development

## Project Structure

```
candyflix/
  backend/     FastAPI app (modular monolith: api/ services/ providers/ models/ schemas/ core/)
  frontend/    Next.js app
  docker-compose.yml
```

## Running locally with Docker (recommended)

1. Copy env files:
   ```
   cp backend/.env.example backend/.env
   cp frontend/.env.local.example frontend/.env.local
   ```
2. Start everything:
   ```
   docker compose up --build
   ```
   (Database migrations are applied automatically: the container's
   entrypoint runs `alembic upgrade head`, and the app itself does the
   same when it starts — so even a hot reload picks up new migrations.
   You never type it. Set `AUTO_MIGRATE=false` to turn the in-app step off.)
3. Visit:
   - Frontend: http://localhost:3000
   - Backend: http://localhost:8000/api
   - Health check: http://localhost:8000/api/health/full

## Running locally without Docker

**Backend** (requires local PostgreSQL + Redis running):
```
cd backend
pip install -r requirements.txt --break-system-packages   # or use a venv
cp .env.example .env    # edit DATABASE_URL/REDIS_URL if needed
alembic upgrade head    # applies migrations — required before first run
uvicorn app.main:app --reload
```

**Frontend:**
```
cd frontend
npm install
cp .env.local.example .env.local
npm run dev
```

## Environment Variables

See `backend/.env.example` and `frontend/.env.local.example` for the
full list. Nothing sensitive is committed — `.env` and `.env.local`
are gitignored.

## Creating users (no signup — invite-only by design)

There's no public signup form. Create each person's account via the
CLI, which prompts for a password securely (never as a CLI argument,
so it never lands in shell history):

```
docker compose exec backend python -m app.cli create-user candy "Candy"
docker compose exec backend python -m app.cli create-user mom "Mom"
docker compose exec backend python -m app.cli create-user sister "Sister"
```

Add `--admin` to make someone an admin right away, or change it later:
```
docker compose exec backend python -m app.cli create-user dad "Dad" --admin
docker compose exec backend python -m app.cli set-admin mom            # promote
docker compose exec backend python -m app.cli set-admin mom --revoke   # demote
```
Admins also get an **Admin panel** (from the name menu) for adding users,
resetting passwords, disabling/deleting accounts, a usage dashboard and
system health. Everyone can change their profile picture, display name and
password in Settings → Account.

List existing users:
```
docker compose exec backend python -m app.cli list-users
```

Running without Docker: same commands, just `python -m app.cli ...`
from inside `backend/` with your virtualenv active.

## TMDB Setup

CandyFlix uses TMDB for all movie/TV metadata. Get a free key:

1. https://www.themoviedb.org/settings/api → request an API key ("Developer" use)
2. Copy the **API Key (v3 auth)**
3. Add it to `backend/.env`: `TMDB_API_KEY=your_key_here`

Without a key, trending/search/detail endpoints return a clear
`500 TMDB_API_KEY is not configured` rather than failing silently.

### Media endpoints

```
GET /api/trending?window=day|week              # movies+tv mixed, defaults to day
GET /api/search?q=...                          # movies+tv
GET /api/movies/popular
GET /api/movies/{tmdb_id}                      # movie details
GET /api/movies/{tmdb_id}/similar              # "You May Also Like"
GET /api/tv/popular
GET /api/tv/{tmdb_id}                          # tv show details + season list
GET /api/tv/{tmdb_id}/similar                  # "You May Also Like"
GET /api/tv/{tmdb_id}/season/{season_number}   # episode list for a season
```

Every result includes a `rating` field (TMDB's own community score —
not IMDb's, since TMDB doesn't provide that).

Responses are cached in Redis (15 min for trending/search, 6 hours
for details) to stay within TMDB's rate limits.

## Testing

**Backend** (TMDB is mocked — no API key or network needed to run these):
```
cd backend
python -m pytest tests/ -v
```

**Frontend** — mounts the real components and drives them with real
clicks/typing; network calls go to a real running backend, so start
the backend first:

```
cd backend && ./entrypoint.sh &     # or: alembic upgrade head && uvicorn app.main:app --reload
cd frontend
npm run test
```

## Implementation Plan

1. ✅ Project setup
2. ✅ Auth (User model, Argon2 hashing, sessions, "Who's watching?" UI)
3. ✅ TMDB integration (trending, search, details, seasons/episodes)
4. ✅ Candy UI (Candy at Night visual system, layout, navigation)
5. ✅ Playback (custom player against local mock video; OpenSubtitles
   for real subtitle discovery; player polish — see PHASE_HANDOFF.md)
6. ✅ Candy Box (per-user watchlist)
7. Continue Watching (per-user progress) — next up
8. Polish (loading/error states, mobile, animations)

Future, out of scope for now: **Candy Server** — a self-hosted media
pipeline for content we have legitimate rights to. No real third-party
*playback* providers will ever be built (product decision) — only
mock/local playback, indefinitely. See `backend/app/providers/README.md`.
